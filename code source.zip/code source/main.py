import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from toolbar import Toolbar
from plugin_manager import PluginManager
from plugin_ui import PluginManagerWindow
from tkhtmlview import HTMLLabel
import markdown
import os

class Onglet:
    def __init__(self, parent, nom="Sans titre"):
        self.nom = nom
        self.frame = tk.Frame(parent)
        self.texte = tk.Text(self.frame, wrap="word")
        self.texte.pack(expand=True, fill="both")
        self.preview = HTMLLabel(self.frame, html="")
        self.preview.pack_forget()
        self.fichier = None
        self.en_mode_markdown = False

    def afficher_markdown(self):
        html = markdown.markdown(self.texte.get("1.0", "end"))
        self.preview.set_html(html)
        self.texte.pack_forget()
        self.preview.pack(expand=True, fill="both")
        self.en_mode_markdown = True

    def cacher_markdown(self):
        self.preview.pack_forget()
        self.texte.pack(expand=True, fill="both")
        self.en_mode_markdown = False

    def set_lecture_seule(self, etat):
        state = "disabled" if etat else "normal"
        self.texte.config(state=state)

class Editeur(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Gnotes")
        self.geometry("1000x700")

        self.lecture_mode = False
        self.onglets = []

        self.creer_barre_outils()
        self.creer_notebook()
        self.creer_barre_etat()
        self.creer_plugin_manager()
        self.creer_menu()

        self.nouvel_onglet()

        self.bind_all("<Control-n>", lambda e: self.nouvel_onglet())
        self.bind_all("<Control-l>", lambda e: self.toggle_read_only())

    def creer_barre_outils(self):
        self.toolbar = Toolbar(self, self.toggle_read_only)
        self.toolbar.pack(side=tk.TOP, fill=tk.X)
        self.toolbar.add_button(command=self.open_plugin_manager, tooltip="Gérer les plugins")

    def creer_notebook(self):
        self.tabs = ttk.Notebook(self)
        self.tabs.pack(expand=True, fill="both")

    def creer_barre_etat(self):
        self.lbl_lecture_mode = tk.Label(self, text="", fg="red")
        self.lbl_lecture_mode.pack(side=tk.BOTTOM, fill=tk.X)

    def creer_plugin_manager(self):
        self.plugin_manager = PluginManager(self, self.toolbar)
        self.plugin_manager.discover_plugins()

    def creer_menu(self):
        menu = tk.Menu(self)
        self.config(menu=menu)

        fichier_menu = tk.Menu(menu, tearoff=0)
        fichier_menu.add_command(label="Nouveau", command=self.nouvel_onglet)
        fichier_menu.add_command(label="Ouvrir", command=self.ouvrir_fichier)
        fichier_menu.add_command(label="Enregistrer", command=self.sauvegarder_fichier)
        fichier_menu.add_command(label="Enregistrer sous...", command=self.sauvegarder_fichier_sous)
        fichier_menu.add_separator()
        fichier_menu.add_command(label="Quitter", command=self.quit)
        menu.add_cascade(label="Fichier", menu=fichier_menu)

    def nouvel_onglet(self, nom="Sans titre"):
        onglet = Onglet(self.tabs, nom=nom)
        self.onglets.append(onglet)
        self.tabs.add(onglet.frame, text=nom)
        self.tabs.select(onglet.frame)
        return onglet

    def onglet_actif(self):
        i = self.tabs.index(self.tabs.select())
        return self.onglets[i]

    def ouvrir_fichier(self):
        chemin = filedialog.askopenfilename(
            filetypes=[("Fichiers texte", "*.txt *.md"), ("Tous les fichiers", "*.*")]
        )
        if chemin:
            with open(chemin, "r", encoding="utf-8") as f:
                contenu = f.read()
            onglet = self.nouvel_onglet(nom=os.path.basename(chemin))
            onglet.texte.insert("1.0", contenu)
            onglet.fichier = chemin
            self.tabs.tab(onglet.frame, text=os.path.basename(chemin))

    def sauvegarder_fichier(self):
        onglet = self.onglet_actif()
        if hasattr(onglet, "fichier") and onglet.fichier:
            with open(onglet.fichier, "w", encoding="utf-8") as f:
                f.write(onglet.texte.get("1.0", "end-1c"))
        else:
            self.sauvegarder_fichier_sous()

    def sauvegarder_fichier_sous(self):
        onglet = self.onglet_actif()
        chemin = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Fichiers texte", "*.txt *.md"), ("Tous les fichiers", "*.*")]
        )
        if chemin:
            with open(chemin, "w", encoding="utf-8") as f:
                f.write(onglet.texte.get("1.0", "end-1c"))
            onglet.fichier = chemin
            self.tabs.tab(onglet.frame, text=os.path.basename(chemin))

    def toggle_read_only(self):
        self.lecture_mode = not self.lecture_mode
        for onglet in self.onglets:
            onglet.set_lecture_seule(self.lecture_mode)
        self.update_mode_lecture_seule_ui()

    def update_mode_lecture_seule_ui(self):
        self.toolbar.update_icon(self.lecture_mode)
        self.lbl_lecture_mode.config(
            text="Lecture seule activée" if self.lecture_mode else ""
        )

    def open_plugin_manager(self):
        PluginManagerWindow(self.plugin_manager)

if __name__ == "__main__":
    app = Editeur()
    app.mainloop()