#!/bin/bash
set -e

APP_NAME="Gnotes"
VERSION="1.0.0"
BUILD_DIR="build"
APPDIR="${BUILD_DIR}/AppDir"

mkdir -p "$APPDIR/usr/bin"
mkdir -p "$APPDIR/usr/share/applications"
mkdir -p "$APPDIR/usr/share/icons/hicolor/256x256/apps"

# Copier le script principal
cp ../éditeur_avancé.py "$APPDIR/usr/bin/blocnotespro"
chmod +x "$APPDIR/usr/bin/blocnotespro"

# Copier icône (à adapter)
cp ../icon.png "$APPDIR/usr/share/icons/hicolor/256x256/apps/blocnotespro.png"

# Desktop file
cat > "$APPDIR/usr/share/applications/blocnotespro.desktop" << EOF
[Desktop Entry]
Name=Gnotes
Exec=Gnotes
Icon=Gnotes
Type=Application
Categories=Utility;TextEditor;
EOF

# Création AppImage avec appimagetool
appimagetool "$APPDIR" "${BUILD_DIR}/${APP_NAME}-${VERSION}.AppImage"
echo "AppImage généré dans ${BUILD_DIR}/${APP_NAME}-${VERSION}.AppImage"
