import os
import zipfile
from pathlib import Path

def create_zip():
    base_dir = Path(__file__).parent.parent
    zip_path = base_dir / "build" / "Gnotes.zip"
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as archive:
        for folder, _, files in os.walk(base_dir):
            if "build" in folder.split(os.sep):
                continue
            for file in files:
                filepath = Path(folder) / file
                arcname = filepath.relative_to(base_dir)
                archive.write(filepath, arcname)
    print(f"Archive ZIP créée : {zip_path}")

if __name__ == "__main__":
    create_zip()
