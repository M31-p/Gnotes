def load(app, toolbar):
    def toggle_read_only():
        app.toggle_read_only()

    toolbar.add_button(
        command=toggle_read_only,
        tooltip="Lecture seule (plugin)"
    )
    return {"name": "ReadOnlyPlugin"}