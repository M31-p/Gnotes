import threading
import time

def init_plugin(app):
    def autosave_loop():
        while True:
            if app and app.onglets and app.winfo_exists():
                for onglet in app.onglets:
                    if onglet.fichier:
                        contenu = onglet.texte.get("1.0", "end")
                        with open(onglet.fichier, "w", encoding="utf-8") as f:
                            f.write(contenu)
                time.sleep(300)  # sauvegarde toutes les 5 min
            else:
                break

    t = threading.Thread(target=autosave_loop, daemon=True)
    t.start()