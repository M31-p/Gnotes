def init_plugin(app):
    # Ajoute une commande dans le menu Plugins
    def basculer_lecture_seule():
        app.toggle_mode_lecture_seule()

    app.plugins_menu = getattr(app, 'plugins_menu', None)
    if app.plugins_menu is None:
        menubar = app.nametowidget(app.winfo_parent()).children.get('menu')
        if menubar:
            app.plugins_menu = menubar.children.get('plugins')

    if app.plugins_menu:
        app.plugins_menu.add_command(label="Activer/Désactiver mode lecture seule", command=basculer_lecture_seule)
