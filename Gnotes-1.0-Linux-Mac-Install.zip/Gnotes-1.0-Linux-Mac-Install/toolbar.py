import tkinter as tk

class Toolbar(tk.Frame):
    def __init__(self, master, toggle_read_only_callback):
        super().__init__(master)
        self.pack(side=tk.TOP, fill=tk.X)
        self.buttons = []

        self.icon_var = tk.StringVar()
        self.icon_var.set("🔓")

        self.btn = tk.Button(
            self,
            textvariable=self.icon_var,
            command=toggle_read_only_callback
        )
        self.btn.pack(side=tk.LEFT, padx=2, pady=2)

    def update_icon(self, locked):
        self.icon_var.set("🔒" if locked else "🔓")

    def add_button(self, command, tooltip="", icon_path=None):
        button = tk.Button(self, text=tooltip, command=command)
        button.pack(side=tk.LEFT, padx=2, pady=2)
        self.buttons.append(button)
        return button