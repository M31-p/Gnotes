import importlib.util
import os

class PluginManager:
    def __init__(self, app, toolbar):
        self.app = app
        self.toolbar = toolbar
        self.plugins = {
    "nom_plugin": {
        "enabled": False,
        "module": None,
        "path": "plugins/nom_plugin.py"
    }
}


    def discover_plugins(self, plugins_path='plugins'):
        if not os.path.exists(plugins_path):
            os.makedirs(plugins_path)

        for file in os.listdir(plugins_path):
            if file.endswith(".py"):
                plugin_name = file[:-3]
                path = os.path.join(plugins_path, file)
                self.plugins[plugin_name] = {
                    "enabled": False,
                    "module": None,
                    "path": path
                }

    def enable_plugin(self, name):
        plugin = self.plugins[name]
        if plugin["enabled"]:
            return
        spec = importlib.util.spec_from_file_location(name, plugin["path"])
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        if hasattr(module, "load"):
            module.load(app=self.app, toolbar=self.toolbar)
            plugin["module"] = module
            plugin["enabled"] = True

    def disable_plugin(self, name):
        plugin = self.plugins[name]
        if plugin["enabled"] and hasattr(plugin["module"], "unload"):
            plugin["module"].unload(app=self.app, toolbar=self.toolbar)
        plugin["enabled"] = False
        plugin["module"] = None