#!/bin/bash
set -e

APP_NAME="Gnotes"
VERSION="1.0.0"
BUILD_DIR="build"
DEB_DIR="${BUILD_DIR}/deb"
INSTALL_DIR="${DEB_DIR}/usr/local/${APP_NAME}"

mkdir -p "$INSTALL_DIR"
cp -r ../* "$INSTALL_DIR/"

# Création du dossier DEBIAN et contrôle
mkdir -p "${DEB_DIR}/DEBIAN"
cat > "${DEB_DIR}/DEBIAN/control" << EOF
Package: $APP_NAME
Version: $VERSION
Section: editors
Priority: optional
Architecture: all
Depends: python3, python3-tk
Maintainer: Nathan VARIN <nathan.varin@outlook.fr>
Description: Editeur de texte  en Python multi-plateforme
EOF

dpkg-deb --build "$DEB_DIR" "${BUILD_DIR}/${APP_NAME}_${VERSION}.deb"
echo "Paquet .deb généré : ${BUILD_DIR}/${APP_NAME}_${VERSION}.deb"
