import tkinter as tk

class PluginManagerWindow(tk.Toplevel):
    def __init__(self, plugin_manager):
        super().__init__()
        self.title("Gestionnaire de plugins")
        self.plugin_manager = plugin_manager
        self.geometry("400x300")

        self.checkbox_vars = {}

        row = 0
        for plugin_name, plugin_data in self.plugin_manager.plugins.items():
            var = tk.BooleanVar(value=plugin_data["enabled"])
            cb = tk.Checkbutton(
                self,
                text=plugin_name,
                variable=var,
                command=lambda name=plugin_name, v=var: self.toggle_plugin(name, v)
            )
            cb.grid(row=row, column=0, sticky="w", padx=10, pady=5)
            self.checkbox_vars[plugin_name] = var
            row += 1

    def toggle_plugin(self, name, var):
        if var.get():
            self.plugin_manager.enable_plugin(name)
        else:
            self.plugin_manager.disable_plugin(name)